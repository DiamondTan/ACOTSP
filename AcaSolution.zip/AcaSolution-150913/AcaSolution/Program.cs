﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AcaSolution
{
    class Program
    {
        static void Main(string[] args)
        {
            //TspTime model = new TspTime();
            //model.TspCalculate();

            //Dictionary<Int32, double> res = new Dictionary<int, double>();
            //res.Add(3, 33.33); res.Add(5, 10.1); res.Add(6, 15.3);
            //var item = res.Min();
            BaseTspAntSystem.Test();
            Console.WriteLine("完成");
            Console.ReadKey();
        }
    }
}
