﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AcaSolution
{
    /// <summary>禁忌表参数</summary>
    public struct TabuList
    {
        public string[] name;
        public int length;
    }

    public class TspTime
    {

        public void TspCalculate()
        {
            /*-------------------------------------------第一步变量初始化--------------------------------------------------*/
            int n = 31;//定义城市个数
            int m = 31;//定义蚂蚁个数
            //定义一个N个城市的坐标数组
            double[,] coordinate = new double[32, 2] { { 25.0, 12.0 }, { 38, 16 }, { 15, 26 }, { 14, 35 }, { 29, 25.0 }, { 22.0, 33.0 }, { 45,22},{36,36 }, {48,18 }, { 42,46 },
                                                       { 65.0, 19.0 }, {58, 26 }, { 25, 56 }, { 14, 59 }, { 29, 75 }, { 72.0, 33.0 }, { 85,41},{46,56 }, {68,38 }, { 49,52 },
                                                       { 55.0, 12.0 }, { 18, 66 }, { 13, 73 }, { 74, 35 }, { 79, 35 }, { 70, 13.0 }, { 25,76},{66,26 }, {28,88 }, { 92,23 },
                                                       { 68,29 }, { 92,15 }};
            int NC = 0;
            int NC_max = 10; //定义一个最大迭代的次数
            int alpha = 1;   //信息启发式因子，表征信息素重要程度的参数
            int beta = 5;    //期望启发式因子，表征启发式因子重要程度的参数
            double Rho = 0.1;//信息素蒸发的参数
            int Q = 100;     //信息素增加强度系数
            int[] Ant = new int[m];//蚂蚁对象
            double[,] Tau = new double[n, n];//定义信息素矩阵
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++) Tau[i, j] = 1;//初始的信息素都为1
            }
            int[][] Tabu;//定义禁忌表,表述已访问的城市，存储并记录路径的生成
            int[][] R_best;//各代的最佳路线
            R_best = new int[NC_max][];
            for (int i = 0; i < NC_max; i++) R_best[i] = new int[n];//每次迭代路径的初始化
            double[,] L_best = new double[NC_max, 1];//各代最佳路线的长度
            double[,] L_aver = new double[NC_max, 1];//各代最佳路线的平均长度
         
            /*---迭代次数循环----*/
            while (NC < NC_max)
            {
                /*------第二步将m只蚂蚁随机放在n个城市中的m个----*/
                int M = 32;//为什么是32？
                int A = 13;
                int C = 5;
                int[] S = new int[M + 1];
                S[0] = 1;
                Ant[0] = S[0];

                //禁忌表初始化，m个蚂蚁就有m个数组
                Tabu = new int[m][];
                for (int i = 0; i < m; i++) Tabu[i] = new int[n];

                Tabu[0][0] = Ant[0];
                for (int i = 0; i < 10; i++)
                {
                    S[i + 1] = (A * S[i] + C) % M;
                    Ant[i + 1] = S[i + 1];
                    Tabu[i + 1][0] = Ant[i + 1];
                }
                S[11] = 0;
                for (int i = 11; i < m; i++)//为什么要从10这里分开？
                {
                    S[i + 1] = (A * S[i] + C) % M;
                    Ant[i] = S[i + 1];
                    Tabu[i][0] = Ant[i];
                }

                int[][] Jtabu;
                Jtabu = new int[m][];
                for (int i = 0; i < m; i++) Jtabu[i] = new int[n];

                /*-------------------------第三步，m只蚂蚁按概率选择下一个城市,依次访问-------------------------------*/
                visiting_city(n, m, Tabu, Jtabu, Tau, coordinate, alpha, beta);

                //加速收敛
                if (NC >= 2)
                {
                    for (int i = 0; i < n; i++) Tabu[0][i] = R_best[NC - 1][i];
                }

                /*------------------------------第四步记录本次迭代的最佳路线----------------------------------------*/
                double[,] L = new double[m, 1];  //定义一个m*1维的数组用来盛放路径长度
                int[][] R;                       //定义一个m*n的数组来记录每条路径
                R = new int[m][];
                for (int i = 0; i < n; i++) R[i] = new int[n];

                //计算各条路径长度
                for (int i = 0; i < m; i++)
                {
                    for (int j = 0; j < n; j++) R[i][j] = Tabu[i][j];

                    L[i, 0] = compute_length(R[i], n, coordinate);
                }

                //对所有的路径长度进行排序，记录最好的
                double sumL = 0;
                int[] mid_R = new int[n];
                for (int i = 0; i < m - 1; i++)
                {
                    if (L[i, 0] < L[i + 1, 0])
                    {
                        double len = L[i, 0];
                        L[i, 0] = L[i + 1, 0];
                        L[i + 1, 0] = len;
                        mid_R = R[i];
                        R[i] = R[i + 1];
                        R[i + 1] = mid_R;
                    }
                    sumL = sumL + L[i, 0];
                }
                L_best[NC, 0] = L[m - 1, 0];                                //存储最优路径长
                L_aver[NC, 0] = sumL / m;                                   //存储此代中的平均路径长
                R_best[NC] = R[m - 1];                                      //存储此代中的最优路径          
                NC = NC + 1;

                /*---------------------------第五步更新信息素--------------------------------*/
                update(n, m, Tabu, L, Tau, Rho, Q);
                /*-----------------------------第六步禁忌表清零--------------------------------*/
                clear(Tabu, m, n);
            }
        }

        //更新信息素
        public void update(int n, int m, int[][] Tabu, double[,] L, double[,] Tau, double Rho, int Q)
        {
            double[,] delta_Tau = new double[n + 1, n + 1];
            for (int i = 0; i < m; i++)
            {
                for (int j = 0; j < n - 1; j++)
                {
                    delta_Tau[Tabu[i][j], Tabu[i][j + 1]] = delta_Tau[Tabu[i][j], Tabu[i][j + 1]] + Q / L[i, 0];
                }
                delta_Tau[Tabu[i][n - 1], Tabu[i][1]] = delta_Tau[Tabu[i][n - 1], Tabu[i][1]] + Q / L[i, 0];
            }
            for (int i = 0; i < n; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    Tau[i, j] = (1 - Rho) * Tau[i, j] + delta_Tau[i + 1, j + 1];
                }
            }
        }

        //定义一个函数用来计算两个城市之间的距离
        public double distance(int i, int j, int n, double[,] coordinate)
        {
            double[,] dist = new double[n + 1, n + 1];
            for (int a = 1; a <= n; a++)
            {
                for (int b = 1; b <= n; b++)
                {
                    if (a != b)
                    {
                        dist[a, b] = Math.Sqrt(Math.Pow(coordinate[a, 0] - coordinate[b, 0], 2) + Math.Pow(coordinate[a, 1] - coordinate[b, 1], 2));
                    }
                    else
                    {
                        dist[a, b] = 0;
                    }
                }
            }
            double dis = dist[i, j];
            return dis;
        }

        //计算每条路径的走过路程
        public double compute_length(int[] R, int n, double[,] coordinate)
        {
            double juli = 0;
            double length = 0;
            for (int i = 0; i < n - 1; i++)
            {
                juli = distance(R[i], R[i + 1], 31, coordinate);
                length = length + juli;
            }
            length = length + distance(R[1], R[n - 1], 31, coordinate);
            return length;
        }

        //清空禁忌表
        public void clear(int[][] array, int m, int n)
        {
            for (int i = 0; i < m; i++)
            {
                for (int j = 0; j < n; j++)
                {
                    array[i][j] = 0;
                }
            }
        }

        //选择下一个要访问的城市
        public void visiting_city(int n, int m, int[][] array1, int[][] array2, double[,] Tau, double[,] coordinate, int alpha, int beta)
        {
            for (int j = 1; j < n; j++)
            {
                for (int i = 0; i < m; i++)
                {
                    //取出待访问的城市
                    //array1中方的是已访问的城市，实际就是禁忌表
                    //array2中放的是待访问的城市
                    double[] possibility = new double[n + 1];
                    int visitingcity = 0;
                    int count = 0;
                    for (int k1 = 0; k1 < n; k1++)
                    {
                        int flag = 1;
                        for (int k2 = 0; k2 < n; k2++)
                        {
                            if ((k1 + 1) == array1[i][k2])
                            {
                                flag = 0;
                            }
                        }
                        if (flag == 1)
                        {
                            array2[i][count] = (k1 + 1);
                            count++;
                        }
                    }
                    //计算待访问城市的概率
                    possibility = compute_possibility(n, count, j, array1[i], array2[i], Tau, coordinate, alpha, beta);
                    visitingcity = determine(n, possibility, array2[i]);
                    array1[i][j] = visitingcity;
                }
            }
        }

        //计算待访问城市的概率
        public double[] compute_possibility(int n, int count, int j, int[] visited, int[] visiting, double[,] Tau, double[,] coordinate, int alpha, int beta)
        {
            double[] P = new double[n + 1];
            double probable = 0;
            double[] probability = new double[n + 1];
            for (int k1 = 0; k1 < count; k1++)
            {
                double d = distance(visited[j - 1], visiting[k1], 31, coordinate);
                double Eta = 1 / d;
                P[visiting[k1]] = Math.Pow(Tau[visited[j - 1] - 1, visiting[k1] - 1], alpha) * Math.Pow(Eta, beta);
                probable = probable + P[visiting[k1]];
            }
            for (int k1 = 0; k1 < count; k1++)
            {
                probability[visiting[k1]] = P[visiting[k1]] / probable;
            }
            return probability;
        }

        //按照状态转移概率来确定下一个访问的城市
        public int determine(int n, double[] probability, int[] visiting)
        {
            for (int k1 = 0; k1 < n - 1; k1++)
            {
                if (probability[visiting[k1]] > probability[visiting[k1 + 1]])
                {
                    int mm = visiting[k1];
                    visiting[k1] = visiting[k1 + 1];
                    visiting[k1 + 1] = mm;
                }
            }
            return visiting[n - 1];
        }
    }
}
