﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AcaSolution
{
    /// <summary>
    /// 城市生活垃圾分类运输线路优化Tsp问题研究
    /// 
    /// </summary>
    //public class CityGrbageTsp:BaseTspAntSystem
    //{
    //    //距离要计算，输入为坐标
    //    //时间窗要求
    //}
}
